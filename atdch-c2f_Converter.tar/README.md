# coding-project-template

# Command to create a service worker


`curl https://raw.githubusercontent.com/ibm-developer-skills-network/atdch-c2f_Converter/wip/sw.js -o sw.js`

 This scrip create a new file called SW.js


1. Run below script to reference the index.html file

`curl https://raw.githubusercontent.com/ibm-developer-skills-network/atdch-c2f_Converter/wip/index.html -o index.html`

!ServiceWorkers.png

!CacheStorage.png 

After this script the page should be working offline properly 

!Offline.png

2. 
    `curl https://raw.githubusercontent.com/ibm-developer-skills-network/atdch-c2f_Converter/wip/manifest.json -o manifest.json` 

    This will create a json file. 

3. Type below commend to add the recent create file to index.html

`curl https://raw.githubusercontent.com/ibm-developer-skills-network/atdch-c2f_Converter/wip/index-final.html -o index.html`

    With this you will be able to download the page as an desktop app 